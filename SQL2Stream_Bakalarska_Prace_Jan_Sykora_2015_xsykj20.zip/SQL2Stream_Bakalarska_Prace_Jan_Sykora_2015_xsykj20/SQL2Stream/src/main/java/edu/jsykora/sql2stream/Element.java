/*
 * 
 */
package edu.jsykora.sql2stream;

public interface Element<E> extends Cloneable {

    public Class<E> getClazz();

    public void setClazz(Class<E> clazz);

    public String getAlias();

    public void setAlias(String alias);

    public boolean hasNext();

    public Element<?> visit(String alias);

    public Element<?> getLast();

    public void setLast(Element<?> element);

    public Element<?> getPenultimate();

    public String getStrategy();

    public Element<E> clone() throws CloneNotSupportedException;

}
