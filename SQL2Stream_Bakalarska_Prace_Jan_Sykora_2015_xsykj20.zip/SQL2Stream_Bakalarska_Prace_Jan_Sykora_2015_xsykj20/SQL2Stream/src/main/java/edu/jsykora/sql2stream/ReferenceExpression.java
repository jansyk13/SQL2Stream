package edu.jsykora.sql2stream;

import java.lang.reflect.Field;

import com.foundationdb.sql.parser.ColumnReference;

// TODO: Auto-generated Javadoc

final class ReferenceExpression<O extends Comparable<O>> extends BaseExpression<O> {

    private String target;

    private Field targetField;

    @SuppressWarnings("unchecked")
    protected ReferenceExpression(BaseElement<?> element, ColumnReference reference) throws SQL2StreamException {
	this.target = reference.getColumnName();
	try {
	    this.targetField = element.getClazz().getDeclaredField(target);
	    this.targetField.setAccessible(true);
	    this.o = (O) this.targetField.get(element.getE());
	} catch (Exception e) {
	    throw new SQL2StreamException(e);
	}
    }

    @Override
    public O returnExpression() throws SQL2StreamException {
	return o;
    }

}
