package edu.jsykora.sql2stream;

import java.lang.reflect.Field;
import java.util.function.Function;

import com.foundationdb.sql.parser.ResultColumn;

// TODO: Auto-generated Javadoc

final class ColumnSelectFunction<R> implements Function<BaseElement<?>, ReferenceObject<R>> {

    private String alias;

    private String target;

    private Field targetField;

    protected ColumnSelectFunction(ResultColumn result) {
	this.alias = result.getTableName() != null ? result.getTableName() : result.getName();
	this.target = result.getName();

    }

    @SuppressWarnings("unchecked")
    @Override
    public ReferenceObject<R> apply(BaseElement<?> t) {
	Element<?> local = t.visit(alias);

	if (alias.equals(target)) {
	    return new ReferenceObject<R>((R) t.getE(), alias);
	}

	try {
	    this.targetField = local.getClazz().getDeclaredField(target);
	    this.targetField.setAccessible(true);
	    ReferenceObject<R> result = new ReferenceObject<>((R) this.targetField.get(((BaseElement<?>) local).getE()), alias);
	    return result;
	} catch (Exception e) {
	    return null;
	}

    }
}
