package edu.jsykora.sql2stream;

import java.util.function.BiPredicate;

import com.foundationdb.sql.parser.BinaryRelationalOperatorNode;
import com.foundationdb.sql.parser.ValueNode;

// TODO: Auto-generated Javadoc

final class JoinPredicate<E, N, O extends Comparable<O>> implements BiPredicate<BaseElement<E>, BaseElement<N>> {

    private Expression<O> left;

    private Expression<O> right;

    private String operator;

    private BinaryRelationalOperatorNode node;

    private String leftAlias;

    private Element<?> leftTarget;

    private String rightAlias;

    private Element<?> rightTarget;

    protected JoinPredicate(ValueNode node) {
	this.node = (BinaryRelationalOperatorNode) node;
	this.operator = this.node.getOperator();
	this.leftAlias = this.node.getLeftOperand().getTableName();
	this.rightAlias = this.node.getRightOperand().getTableName();
    }

    @Override
    public boolean test(BaseElement<E> t, BaseElement<N> u) {
	leftTarget = t.visit(leftAlias);
	if (leftTarget == null) {
	    leftTarget = u.visit(leftAlias);
	}
	try {
	    left = BaseExpression.createBaseExpression((BaseElement<?>) leftTarget, node.getLeftOperand());
	} catch (Exception e1) {
	    return false;
	}

	rightTarget = t.visit(rightAlias);
	if (rightTarget == null) {
	    rightTarget = u.visit(rightAlias);
	}
	try {
	    right = BaseExpression.createBaseExpression((BaseElement<?>) rightTarget, node.getRightOperand());
	} catch (Exception e1) {
	    return false;
	}
	try {
	    O o1 = left.returnExpression();
	    O o2 = right.returnExpression();
	    int result = o1.compareTo(o2);
	    boolean resultBoolean = Expression.getResult(operator, result);
	    return resultBoolean;
	} catch (SQL2StreamException e) {
	    return false;
	}

    }
}
