package edu.jsykora.sql2stream;

import com.foundationdb.sql.parser.BinaryRelationalOperatorNode;

// TODO: Auto-generated Javadoc

final class LeafPredicate<T, O extends Comparable<O>> extends BasePredicate<T> {

    private BinaryRelationalOperatorNode node;

    private Expression<O> right;

    private Expression<O> left;

    private O o;

    private boolean failFlag;

    private String operator;

    private String leftAlias;

    private Element<?> leftTarget;

    protected LeafPredicate(BinaryRelationalOperatorNode node) {
	this.node = node;
	this.failFlag = false;
	this.operator = this.node.getOperator();
	this.leftAlias = this.node.getLeftOperand().getTableName();
	this.right = ValueExpression.createValueExpression(node.getRightOperand());
	try {
	    this.o = right.returnExpression();
	} catch (SQL2StreamException e) {
	    this.failFlag = true;
	}

    }

    @Override
    public boolean test(BaseElement<T> t) {
	if (failFlag) {
	    return false;
	}
	leftTarget = t.visit(leftAlias);

	try {
	    left = BaseExpression.createBaseExpression((BaseElement<?>) leftTarget, node.getLeftOperand());
	} catch (Exception e1) {
	    return false;
	}

	try {
	    O current = left.returnExpression();
	    int result = o.compareTo(current);
	    boolean resultBoolean = Expression.getResult(operator, result);
	    return resultBoolean;
	} catch (SQL2StreamException e) {
	    return false;
	}

    }

}
