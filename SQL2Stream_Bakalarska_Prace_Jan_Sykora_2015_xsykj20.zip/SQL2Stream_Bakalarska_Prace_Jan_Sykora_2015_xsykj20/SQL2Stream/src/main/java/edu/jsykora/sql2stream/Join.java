package edu.jsykora.sql2stream;

import java.util.List;

// TODO: Auto-generated Javadoc

interface Join<E> {

    List<BaseElement<E>> interpret();
}
