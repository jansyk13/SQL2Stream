package edu.jsykora.sql2stream;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.StreamSupport;

import com.foundationdb.sql.parser.FromBaseTable;
import com.foundationdb.sql.parser.QueryTreeNode;

// TODO: Auto-generated Javadoc

@SuppressWarnings("rawtypes")
final class SourceJoin extends AbstractJoin {

    private FromBaseTable node;

    private String target;

    private List<BaseElement<? extends Object>> targetList;

    @SuppressWarnings("unchecked")
    protected SourceJoin(SourceElement<?> source, QueryTreeNode node) {
	super(source);
	this.node = (FromBaseTable) node;
	this.target = this.node.getCorrelationName();

    }

    @Override
    public List<BaseElement<? extends Object>> interpret() {
	this.targetList = new ArrayList<BaseElement<?>>();
	StreamSupport.stream(((SourceElement<?>) getSource().visit(target)).getIterable().spliterator(), false).forEach(t -> {
	    TerminalBaseElement<Object> test = TerminalBaseElement.createTerminateBaseElement(t, target);
	    targetList.add(test);
	});
	return targetList;
    }
}
